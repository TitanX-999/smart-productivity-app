/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  Sparkles, 
  Send, 
  Play, 
  Pause, 
  RefreshCcw, 
  Flame, 
  Zap, 
  Type as FontIcon, 
  Layers, 
  Languages, 
  Download,
  Music,
  ChevronRight,
  Plus
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { generateScript, generateVoiceover, generateImage, optimizeForViral, generateMusic, VideoScript } from './lib/gemini';

// ... (types and NICHE_TEMPLATES)
type AppState = 'idle' | 'generating' | 'preview';
type Language = 'English' | 'Arabic' | 'Darija';
type Style = 'Cinematic' | 'Motivational' | 'Educational' | 'Storytelling';

const NICHE_TEMPLATES = [
  { id: 'motivation', name: 'Motivational', icon: <Flame size={18} />, color: 'bg-orange-500' },
  { id: 'facts', name: 'Cool Facts', icon: <Zap size={18} />, color: 'bg-blue-500' },
  { id: 'business', name: 'Business Tips', icon: <Layers size={18} />, color: 'bg-green-500' },
  { id: 'stories', name: 'Human Stories', icon: <Plus size={18} />, color: 'bg-purple-500' },
];

export default function App() {
  const [state, setState] = useState<AppState>('idle');
  const [topic, setTopic] = useState('');
  const [style, setStyle] = useState<Style>('Storytelling');
  const [language, setLanguage] = useState<Language>('English');
  const [script, setScript] = useState<VideoScript | null>(null);
  const [scenes, setScenes] = useState<string[]>([]);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [musicUrl, setMusicUrl] = useState<string | null>(null);
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [loadingStep, setLoadingStep] = useState('');

  const handleGenerate = async () => {
    if (!topic) return;
    setState('generating');
    try {
      setLoadingStep('Writing viral script...');
      const newScript = await generateScript(topic, style, language);
      setScript(newScript);

      setLoadingStep('Synthesizing AI voiceover...');
      const fullText = [newScript.hook, ...newScript.body, newScript.callToAction].join(' ');
      const audio = await generateVoiceover(fullText);
      setAudioUrl(audio);

      setLoadingStep('Composing background music...');
      const music = await generateMusic(`Upbeat modern ${style} background music for TikTok`);
      setMusicUrl(music);

      setLoadingStep('Generating visual scenes...');
      const visualTasks = newScript.visualPrompts.slice(0, 4).map(p => generateImage(p));
      const visualUrls = await Promise.all(visualTasks);
      setScenes(visualUrls);

      setState('preview');
    } catch (error) {
      console.error(error);
      alert('Error generating content. Please try again.');
      setState('idle');
    }
  };

  const handleMakeViral = async () => {
    if (!script) return;
    setIsOptimizing(true);
    try {
      const optimized = await optimizeForViral(script);
      setScript(optimized);
    } catch (error) {
      console.error(error);
    } finally {
      setIsOptimizing(false);
    }
  };

  return (
    <div className="min-h-screen bg-bg text-white font-sans selection:bg-accent selection:text-white flex flex-col relative overflow-hidden">
      {/* Background Glows */}
      <div className="fixed top-[-100px] right-[-100px] w-[400px] h-[400px] bg-accent-glow rounded-full blur-[80px] pointer-events-none z-0" />
      <div className="fixed bottom-[-100px] left-[-100px] w-[300px] h-[300px] bg-blue-500/10 rounded-full blur-[80px] pointer-events-none z-0" />

      {/* Header */}
      <header className="relative z-20 px-10 py-6 border-b border-border-dim flex justify-between items-center bg-bg/50 backdrop-blur-md">
        <div className="text-xl font-extrabold tracking-widest bg-gradient-to-r from-white to-accent bg-clip-text text-transparent italic">
          VIRAL.FLOW
        </div>
        <div className="flex items-center gap-5">
          <div className="text-[12px] text-text-dim bg-white/5 px-3 py-1.5 rounded-full border border-border-dim font-medium uppercase tracking-tight">
            48 Credits Remaining
          </div>
          <div className="w-8 h-8 rounded-full bg-white/10 border border-border-dim flex items-center justify-center overflow-hidden">
            <div className="w-full h-full bg-gradient-to-br from-accent/50 to-blue-500/50" />
          </div>
        </div>
      </header>

      {/* Main Layout */}
      <main className="relative z-10 grid grid-cols-1 lg:grid-cols-[420px_1fr] flex-1 overflow-hidden p-10 gap-8">
        
        {/* Editor Pane (Left) */}
        <section className="flex flex-col gap-6 overflow-y-auto pr-4 scrollbar-hide">
          <AnimatePresence mode="wait">
            {state !== 'preview' ? (
              <motion.div 
                key="editor"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="space-y-2">
                  <label className="text-[11px] uppercase tracking-widest text-text-dim font-bold">Your Topic or Idea</label>
                  <textarea 
                    value={topic}
                    onChange={(e) => setTopic(e.target.value)}
                    placeholder="E.g. 3 psychological tricks to double your productivity..."
                    className="w-full h-32 bg-card-bg border border-border-dim rounded-xl p-4 text-sm focus:outline-none focus:border-accent/50 transition-all resize-none shadow-inner"
                  />
                </div>

                <div className="space-y-3">
                  <label className="text-[11px] uppercase tracking-widest text-text-dim font-bold">Video Style</label>
                  <div className="grid grid-cols-2 gap-3">
                    {(['Cinematic', 'Motivational', 'Educational', 'Storytelling'] as Style[]).map(s => (
                      <button 
                        key={s}
                        onClick={() => setStyle(s)}
                        className={`flex items-center gap-3 p-3 rounded-xl border transition-all ${style === s ? 'bg-accent/10 border-accent shadow-[0_0_15px_rgba(157,80,255,0.2)]' : 'bg-card-bg border-border-dim hover:border-white/20'}`}
                      >
                        <div className="w-8 h-8 bg-white/5 rounded-lg flex items-center justify-center text-sm">
                          {s === 'Cinematic' && '🎬'}
                          {s === 'Motivational' && '🔥'}
                          {s === 'Educational' && '📚'}
                          {s === 'Storytelling' && '🎭'}
                        </div>
                        <span className="text-[13px] font-medium">{s}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <label className="text-[11px] uppercase tracking-widest text-text-dim font-bold">Voice & Language</label>
                  <div className="flex gap-2">
                    {(['English', 'Arabic', 'Darija'] as Language[]).map(lang => (
                      <button 
                        key={lang}
                        onClick={() => setLanguage(lang)}
                        className={`px-4 py-1.5 rounded-full text-xs font-semibold transition-all ${language === lang ? 'bg-white text-black' : 'bg-white/5 text-text-dim hover:bg-white/10 border border-border-dim'}`}
                      >
                        {lang}
                      </button>
                    ))}
                  </div>
                  <div className="flex items-center gap-3 p-3 rounded-xl border border-border-dim bg-card-bg cursor-pointer hover:bg-white/5 transition-colors group">
                    <div className="w-8 h-8 bg-white/5 rounded-lg flex items-center justify-center text-sm group-hover:bg-accent/20 transition-colors">🎙️️</div>
                    <span className="text-[13px]">AI Voice: "Modern Narrator"</span>
                  </div>
                </div>

                <button 
                  onClick={handleGenerate}
                  disabled={!topic || state === 'generating'}
                  className="w-full mt-4 bg-gradient-to-r from-accent to-[#6E30C1] text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-3 shadow-[0_10px_30px_rgba(157,80,255,0.4)] hover:brightness-110 active:scale-95 transition-all disabled:opacity-50"
                >
                  <span className="text-xl">🚀</span>
                  {state === 'generating' ? 'ANALYZING...' : 'MAKE IT VIRAL'}
                </button>
                <p className="text-center text-text-dim text-[11px]">
                  Optimizing hook, pacing, and dynamic captions automatically.
                </p>
              </motion.div>
            ) : (
              <motion.div 
                key="preview-active"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-bold">Generation complete</h3>
                  <button onClick={() => setState('idle')} className="text-accent text-xs font-bold hover:underline">START NEW</button>
                </div>
                
                <div className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-[11px] uppercase tracking-widest text-text-dim font-bold">The Script</label>
                    <div className="bg-card-bg border border-border-dim rounded-xl p-5 h-[350px] overflow-y-auto scrollbar-hide space-y-5">
                      <p className="text-xl font-black italic tracking-tighter text-accent leading-none">"{script?.hook}"</p>
                      <div className="space-y-3">
                        {script?.body.map((b, i) => (
                           <div key={i} className="flex gap-3">
                              <span className="text-accent/40 font-mono text-[10px] mt-1">0{i+1}</span>
                              <p className="text-sm text-white/80 leading-relaxed font-medium">{b}</p>
                           </div>
                        ))}
                      </div>
                      <div className="pt-4 border-t border-white/5 opacity-50">
                        <p className="text-xs">{script?.callToAction}</p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-[11px] uppercase tracking-widest text-text-dim font-bold">Media Assets</label>
                    <div className="grid grid-cols-4 gap-2">
                       {scenes.map((s, i) => (
                         <div key={i} className="aspect-[9/16] rounded-md overflow-hidden bg-white/5 border border-border-dim group relative">
                            <img src={s} className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all cursor-pointer" referrerPolicy="no-referrer" />
                         </div>
                       ))}
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <button 
                      onClick={handleMakeViral}
                      disabled={isOptimizing}
                      className="flex-1 py-3 bg-accent text-white rounded-xl font-bold flex items-center justify-center gap-2 text-sm shadow-xl shadow-accent/20"
                    >
                      {isOptimizing ? <RefreshCcw className="animate-spin" size={16} /> : <Flame size={16} />}
                      Boost Retention
                    </button>
                    <button className="flex-1 py-3 bg-white text-black rounded-xl font-bold flex items-center justify-center gap-2 text-sm">
                      <Download size={16} />
                      Export MP4
                    </button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </section>

        {/* Preview Pane (Right) */}
        <section className="bg-white/[0.02] rounded-[32px] border border-border-dim flex items-center justify-center relative overflow-hidden">
          {state === 'generating' && (
            <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-bg/80 backdrop-blur-sm gap-6">
              <div className="w-20 h-20 border-4 border-accent/10 border-t-accent rounded-full animate-spin" />
              <div className="text-center space-y-1">
                <p className="text-accent text-xs font-bold tracking-widest uppercase">{loadingStep}</p>
                <p className="text-text-dim text-[10px]">AI Rendering Engine Active</p>
              </div>
            </div>
          )}

          {state === 'idle' ? (
            <div className="text-center space-y-4 opacity-40">
              <div className="w-64 h-[450px] border-2 border-dashed border-white/10 rounded-[32px] flex items-center justify-center">
                 <p className="text-xs font-medium uppercase tracking-widest">Awaiting Input</p>
              </div>
            </div>
          ) : (
            <div className="relative">
               {script && <VideoPlayer script={script} scenes={scenes} audioUrl={audioUrl} musicUrl={musicUrl} />}
               <div className="absolute top-[-40px] right-[-50px] flex items-center gap-3 scale-75 lg:scale-100">
                  <div className="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_10px_#00FF00] animate-pulse" />
                  <span className="text-[11px] text-green-500 font-black tracking-widest uppercase">AI RENDERING ENGINE ACTIVE</span>
               </div>
            </div>
          )}
        </section>
      </main>

      {/* Footer */}
      <footer className="relative z-20 px-10 py-4 border-t border-border-dim flex gap-10 text-[11px] text-text-dim font-bold tracking-tight bg-bg/50">
        <span>TEMPLATES: <b>{NICHE_TEMPLATES.map(t => t.name).join(', ')}</b></span>
        <span>STATUS: <b>{state === 'generating' ? 'RENDERING' : 'READY'}</b></span>
        <span className="ml-auto">VIRAL.FLOW v2.4.0</span>
      </footer>
    </div>
  );
}

// --- Subcomponents ---

function FeatureCard({ title, desc, icon }: { title: string, desc: string, icon: React.ReactNode }) {
  return (
    <div className="p-5 bg-white/[0.02] border border-white/10 rounded-2xl space-y-3 hover:bg-white/[0.04] transition-all cursor-pointer group">
      <div className="w-10 h-10 bg-white/5 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
        {icon}
      </div>
      <div>
        <h4 className="text-sm font-bold">{title}</h4>
        <p className="text-xs text-white/40 leading-relaxed">{desc}</p>
      </div>
    </div>
  );
}

function CaptionStyleCircle({ label, active }: { label: string, active?: boolean }) {
  return (
    <div className={`p-3 rounded-xl border text-[10px] font-bold text-center cursor-pointer transition-all ${active ? 'bg-white text-black border-white' : 'bg-transparent text-white/40 border-white/10 hover:border-white/30'}`}>
      {label}
    </div>
  );
}

function VideoPlayer({ script, scenes, audioUrl, musicUrl }: { script: VideoScript, scenes: string[], audioUrl: string | null, musicUrl: string | null }) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const musicRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    let interval: any;
    if (isPlaying) {
      interval = setInterval(() => {
        if (audioRef.current) {
          setCurrentTime(audioRef.current.currentTime);
          if (audioRef.current.ended) {
            setIsPlaying(false);
            setCurrentTime(0);
          }
        } else {
          setCurrentTime(prev => (prev + 0.1) % 30);
        }
      }, 100);
    }
    return () => clearInterval(interval);
  }, [isPlaying]);

  useEffect(() => {
    if (isPlaying) {
      audioRef.current?.play().catch(e => console.error(e));
      if (musicRef.current) {
        musicRef.current.volume = 0.2;
        musicRef.current.play().catch(e => console.error(e));
      }
    } else {
      audioRef.current?.pause();
      musicRef.current?.pause();
    }
  }, [isPlaying]);

  const currentCaption = script.captions.find(c => currentTime >= c.startTime && currentTime <= c.endTime);
  const currentSceneIndex = Math.min(Math.floor(currentTime / 5), scenes.length - 1);
  const currentScene = scenes[currentSceneIndex] || scenes[0];

  return (
    <div className="relative aspect-[9/16] bg-black rounded-[2rem] overflow-hidden border-[8px] border-white/5 shadow-2xl group mx-auto max-w-[320px]">
      <AnimatePresence mode="wait">
        <motion.img 
          key={currentSceneIndex}
          src={currentScene} 
          initial={{ scale: 1.1, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.95, opacity: 0 }}
          transition={{ duration: 0.8 }}
          className="absolute inset-0 w-full h-full object-cover"
          referrerPolicy="no-referrer"
        />
      </AnimatePresence>

      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/20" />

      {/* Dynamic Captions */}
      <div className="absolute inset-0 flex items-center justify-center p-8 pointer-events-none">
        <AnimatePresence mode="wait">
          {currentCaption && (
            <motion.div 
              key={currentCaption.text}
              initial={{ scale: 0.5, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 1.2, opacity: 0 }}
              className="text-center font-black text-3xl uppercase tracking-tighter drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]"
            >
              <span className="bg-yellow-400 text-black px-2 inline-block -rotate-1 shadow-lg">
                {currentCaption.text}
              </span>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Progress Bar */}
      <div className="absolute bottom-16 left-4 right-4 h-1 bg-white/20 rounded-full overflow-hidden">
        <div 
          className="h-full bg-white transition-all duration-100" 
          style={{ width: `${(currentTime / 30) * 100}%` }}
        />
      </div>

      {/* Controls */}
      <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/20 backdrop-blur-[2px]">
        <button 
          onClick={() => setIsPlaying(!isPlaying)}
          className="w-16 h-16 bg-white text-black rounded-full flex items-center justify-center shadow-xl active:scale-90 transition-transform"
        >
          {isPlaying ? <Pause fill="black" /> : <Play fill="black" className="ml-1" />}
        </button>
      </div>

      <div className="absolute top-4 left-4 flex items-center gap-2">
        <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
        <span className="text-[10px] font-bold uppercase tracking-widest text-white/80">Previewing</span>
      </div>

      {audioUrl && (
        <audio 
          ref={audioRef} 
          src={audioUrl} 
          style={{ display: 'none' }}
        />
      )}
      {musicUrl && (
        <audio 
          ref={musicRef} 
          src={musicUrl} 
          loop
          style={{ display: 'none' }}
        />
      )}
    </div>
  );
}
