import { GoogleGenAI, Type, Modality } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY as string });

export interface VideoScript {
  title: string;
  hook: string;
  body: string[];
  callToAction: string;
  visualPrompts: string[];
  captions: { text: string; startTime: number; endTime: number }[];
}

export const generateScript = async (
  topic: string,
  style: string,
  language: string = "English"
): Promise<VideoScript> => {
  const systemInstruction = `
    You are a viral content creator for TikTok and Instagram Reels. 
    Your goal is to write a high-retention script for a ${style} video.
    The script should follow the Hook-Value-CTA framework.
    Language: ${language}. If Arabic, use appropriate dialect if requested (like Darija).
    
    Return a JSON object:
    {
      "title": "catchy title",
      "hook": "first 3 seconds to grab attention",
      "body": ["point 1", "point 2", "point 3"],
      "callToAction": "what to do next",
      "visualPrompts": ["image prompt for hook", "image prompt for point 1", ...],
      "captions": [
        { "text": "word or phrase", "startTime": 0.5, "endTime": 1.5 },
        ...
      ]
    }
    
    Total duration should be 15-30 seconds. Timings in captions should be precise.
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Topic: ${topic}`,
    config: {
      systemInstruction,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          hook: { type: Type.STRING },
          body: { type: Type.ARRAY, items: { type: Type.STRING } },
          callToAction: { type: Type.STRING },
          visualPrompts: { type: Type.ARRAY, items: { type: Type.STRING } },
          captions: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                text: { type: Type.STRING },
                startTime: { type: Type.NUMBER },
                endTime: { type: Type.NUMBER }
              },
              required: ["text", "startTime", "endTime"]
            }
          }
        },
        required: ["title", "hook", "body", "callToAction", "visualPrompts", "captions"]
      }
    }
  });

  return JSON.parse(response.text);
};

export const generateVoiceover = async (text: string, voiceName: string = "Zephyr"): Promise<string> => {
  const response = await ai.models.generateContent({
    model: "gemini-3.1-flash-tts-preview",
    contents: [{ parts: [{ text }] }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: { voiceName: voiceName as any },
        },
      },
    },
  });

  const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  if (!base64Audio) throw new Error("No audio generated");
  return `data:audio/wav;base64,${base64Audio}`;
};

export const generateImage = async (prompt: string): Promise<string> => {
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        { text: prompt },
      ],
    },
    config: {
      imageConfig: {
        aspectRatio: "9:16",
      },
    },
  });

  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      return `data:image/png;base64,${part.inlineData.data}`;
    }
  }
  
  // Fallback to picsum if image generation fails or returns no image
  return `https://picsum.photos/seed/${encodeURIComponent(prompt)}/1080/1920`;
};

export const optimizeForViral = async (script: VideoScript): Promise<VideoScript> => {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Optimize this script to be more viral: ${JSON.stringify(script)}`,
    config: {
      systemInstruction: "You are a viral growth hacker. Improve the hook, add emojis to captions, and increase the pacing. Return JSON matching the original schema.",
      responseMimeType: "application/json",
    }
  });
  return JSON.parse(response.text);
};

export const generateMusic = async (prompt: string): Promise<string> => {
  try {
    const response = await ai.models.generateContentStream({
      model: "lyria-3-clip-preview",
      contents: prompt,
    });

    let audioBase64 = "";
    for await (const chunk of response) {
      const parts = chunk.candidates?.[0]?.content?.parts;
      if (!parts) continue;
      for (const part of parts) {
        if (part.inlineData?.data) {
          audioBase64 += part.inlineData.data;
        }
      }
    }

    if (!audioBase64) throw new Error("No music generated");

    const binary = atob(audioBase64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    const blob = new Blob([bytes], { type: "audio/wav" });
    return URL.createObjectURL(blob);
  } catch (error) {
    console.warn("Music generation failed, using fallback:", error);
    return "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"; // Fallback placeholder
  }
};
